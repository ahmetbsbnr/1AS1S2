INSERT INTO `CINEMA`(`IDCinema`, `NomCinema`, `Adresse`) VALUES ('2','Le Fontenelle','78160 Marly-le-Roi');
INSERT INTO `CINEMA`(`IDCinema`, `NomCinema`, `Adresse`) VALUES ('1','le renoir','13100 Aix-en-Provence');
INSERT INTO `CINEMA`(`IDCinema`, `NomCinema`, `Adresse`) VALUES ('3','Gaumont ilson','31000 Toulouse');
INSERT INTO `CINEMA`(`IDCinema`, `NomCinema`, `Adresse`) VALUES ('4','Espace Ciné','93800 Epinay-sur-Seine');