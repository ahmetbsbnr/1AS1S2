export function isDigit(c: string): boolean {
  return c >= "0" && c <= "9";
}
